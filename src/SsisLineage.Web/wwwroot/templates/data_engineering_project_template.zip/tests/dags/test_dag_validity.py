from airflow.models import DagBag


def test_no_import_errors():
    """
    Validates that all auto-generated SSIS migration DAGs in the /dags folder
    can be parsed by Airflow without syntax or import errors.
    """
    dag_bag = DagBag()
    
    # Ensure there are no import errors across any of the generated files
    assert len(dag_bag.import_errors) == 0, f"Import failures found: {dag_bag.import_errors}"
    
    # Ensure at least one SSIS package was successfully migrated and loaded as a DAG
    assert dag_bag.size() >= 1, "Expected at least one DAG to be loaded."
